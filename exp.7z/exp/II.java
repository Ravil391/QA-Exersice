// Интерфейс Animal
public interface Animal {
    String getBreed();
    String getName();
    Double getCost();
    String getCharacter();
}

// Абстрактный класс AbstractAnimal
public abstract class AbstractAnimal implements Animal {
    protected String breed;    // порода
    protected String name;     // имя
    protected Double cost;     // цена в магазине
    protected String character; // характер

    public AbstractAnimal(String breed, String name, Double cost, String character) {
        this.breed = breed;
        this.name = name;
        this.cost = cost;
        this.character = character;
    }

    @Override
    public String getBreed() {
        return breed;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Double getCost() {
        return cost;
    }

    @Override
    public String getCharacter() {
        return character;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Breed: " + breed + ", Cost: " + cost + ", Character: " + character;
    }
}

// Конкретный класс Predator
public class Predator extends AbstractAnimal {
    public Predator(String breed, String name, Double cost, String character) {
        super(breed, name, cost, character);
    }

    @Override
    public String toString() {
        return "Predator - " + super.toString();
    }
}

// Конкретный класс Pet
public class Pet extends AbstractAnimal {
    public Pet(String breed, String name, Double cost, String character) {
        super(breed, name, cost, character);
    }

    @Override
    public String toString() {
        return "Pet - " + super.toString();
    }
}

// Класс для создания животных
import java.util.ArrayList;
import java.util.List;

public class CreateAnimalService {
    private List<Animal> animals = new ArrayList<>();

    // Метод для создания 10 уникальных животных
    public void createDefaultAnimals() {
        String[] breeds = {"Lion", "Tiger", "Dog", "Cat", "Falcon", "Eagle", "Goldfish", "Parrot", "Hamster", "Rabbit"};
        String[] names = {"Simba", "Shere Khan", "Buddy", "Whiskers", "Hercules", "Zephyr", "Goldie", "Polly", "Nibbles", "BunBun"};
        Double[] costs = {2500.0, 3000.0, 100.0, 150.0, 300.0, 500.0, 20.0, 100.0, 25.0, 30.0};
        String[] characters = {"Brave", "Fierce", "Friendly", "Playful", "Majestic", "Wise", "Calm", "Talkative", "Curious", "Active"};

        int i = 0;
        while (i < 10) {
            if (i < 5) { // Первые 5 животных - хищники
                animals.add(new Predator(breeds[i], names[i], costs[i], characters[i]));
            } else { // Остальные - домашние питомцы
                animals.add(new Pet(breeds[i], names[i], costs[i], characters[i]));
            }
            System.out.println("Created: " + animals.get(animals.size() - 1));
            i++;
        }
    }

    // Перегруженный метод для создания N животных
    public void createAnimals(int N) {
        String[] breeds = {"Lion", "Tiger", "Dog", "Cat", "Falcon", "Eagle", "Goldfish", "Parrot", "Hamster", "Rabbit"};
        String[] names = {"Simba", "Shere Khan", "Buddy", "Whiskers", "Hercules", "Zephyr", "Goldie", "Polly", "Nibbles", "BunBun"};
        Double[] costs = {2500.0, 3000.0, 100.0, 150.0, 300.0, 500.0, 20.0, 100.0, 25.0, 30.0};

        String[] characters = {"Brave", "Fierce", "Friendly", "Playful", "Majestic", "Wise", "Calm", "Talkative", "Curious", "Active"};

        for (int i = 0; i < N; i++) {
            if (i < 5) { // Первые 5 животных - хищники
                animals.add(new Predator(breeds[i], names[i], costs[i], characters[i]));
            } else { // Остальные - домашние питомцы
                animals.add(new Pet(breeds[i], names[i], costs[i], characters[i]));
            }
            System.out.println("Created: " + animals.get(animals.size() - 1));
        }
    }
    // Метод с использованием do-while
    public void createAnimalsDoWhile(int N) {
        String[] breeds = {"Lion", "Tiger", "Dog", "Cat", "Falcon", "Eagle", "Goldfish", "Parrot", "Hamster", "Rabbit"};
        String[] names = {"Simba", "Shere Khan", "Buddy", "Whiskers", "Hercules", "Zephyr", "Goldie", "Polly", "Nibbles", "BunBun"};
        Double[] costs = {2500.0, 3000.0, 100.0, 150.0, 300.0, 500.0, 20.0, 100.0, 25.0, 30.0};
        String[] characters = {"Brave", "Fierce", "Friendly", "Playful", "Majestic", "Wise", "Calm", "Talkative", "Curious", "Active"};
        int i = 0;
        do {
            if (i < 5) { // Первые 5 животных - хищники
                animals.add(new Predator(breeds[i], names[i], costs[i], characters[i]));
            } else { // Остальные - домашние питомцы
                animals.add(new Pet(breeds[i], names[i], costs[i], characters[i]));
            }
            System.out.println("Created: " + animals.get(animals.size() - 1));
            i++;
        } while (i < N && i < breeds.length); // Предотвращаем выход за пределы массива
    }
}

// Основной класс Main для запуска программы
public class Main {
    public static void main(String[] args) {
        CreateAnimalService createAnimalService = new CreateAnimalService();

        // Создать 10 уникальных животных
        createAnimalService.createDefaultAnimals();

        // Создать N животных (например, 5)
        System.out.println("\nCreating 5 animals:");
        createAnimalService.createAnimals(5);

        // Создать животных с помощью do-while (например, 3)
        System.out.println("\nCreating 3 animals using do-while:");
        createAnimalService.createAnimalsDoWhile(3);
    }
}
