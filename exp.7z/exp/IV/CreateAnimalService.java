import java.util.ArrayList;
import java.util.List;

/**
 * Класс для создания животных.
 */
public class CreateAnimalService {
    private AnimalFactory animalFactory;

    public CreateAnimalService() {
        this.animalFactory = new AnimalFactory();
    }

    public List<Animal> createDefaultAnimals(int numberOfAnimals) {
        List<Animal> animals = animalFactory.createAnimals(numberOfAnimals);
        for (Animal animal : animals) {
            System.out.println("Created: " + animal);
        }
        return animals;
    }
}
