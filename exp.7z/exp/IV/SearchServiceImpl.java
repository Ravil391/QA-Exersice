import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Реализация интерфейса SearchService.
 */
public class SearchServiceImpl implements SearchService {
    
    @Override
    public String[] findLeapYearNames(List<Animal> animals) {
        return animals.stream()
                .filter(animal -> animal.getBirthDate().isLeapYear())
                .map(Animal::getName)
                .toArray(String[]::new);
    }

    @Override
    public List<Animal> findOlderAnimal(List<Animal> animals, int N) {
        return animals.stream()
                .filter(animal -> (LocalDate.now().getYear() - animal.getBirthDate().getYear()) > N)
                .collect(Collectors.toList());
    }

    @Override
    public void findDuplicate(List<Animal> animals) {

        Set<Animal> uniqueAnimals = new HashSet<>();
        Set<Animal> duplicates = new HashSet<>();

        for (Animal animal : animals) {
            if (!uniqueAnimals.add(animal)) {
                duplicates.add(animal);
            }
        }

        if (duplicates.isEmpty()) {
            System.out.println("No duplicates found.");
        } else {
            System.out.println("Duplicate animals:");
            duplicates.forEach(System.out::println);
        }
    }
}
