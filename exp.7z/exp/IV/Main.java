/**
 * Главный класс для запуска программы.
 */
public class Main {
    public static void main(String[] args) {
        CreateAnimalService createAnimalService = new CreateAnimalService();
        SearchService searchService = new SearchServiceImpl();

        // Создать 10 уникальных животных
        List<Animal> animalsList = createAnimalService.createDefaultAnimals(10);

        // Поиск животных, родившихся в високосный год
        String[] leapYearNames = searchService.findLeapYearNames(animalsList);
        System.out.println("\nAnimals born in leap years:");
        Arrays.stream(leapYearNames).forEach(System.out::println);

        // Поиск животных старше N лет
        List<Animal> olderAnimals = searchService.findOlderAnimal(animalsList, 5);
        System.out.println("\nAnimals older than 5 years:");
        olderAnimals.forEach(System.out::println);

        // Поиск дубликатов
        System.out.println("\nFinding duplicates:");
        searchService.findDuplicate(animalsList);
    }
}


