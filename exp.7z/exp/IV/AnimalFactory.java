import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Фабрика для создания животных.
 */
public class AnimalFactory {
    private Random random = new Random();

    public List<Animal> createAnimals(int numberOfAnimals) {
        List<Animal> animals = new ArrayList<>();

        String[] breeds = {"Lion", "Tiger", "Dog", "Cat", "Falcon", "Eagle", "Goldfish", "Parrot", "Hamster", "Rabbit"};
        String[] names = {"Simba", "Shere Khan", "Buddy", "Whiskers", "Hercules", "Zephyr", "Goldie", "Polly", "Nibbles", "BunBun"};
        Double[] costs = {2500.0, 3000.0, 100.0, 150.0, 300.0, 500.0, 20.0, 100.0, 25.0, 30.0};
        String[] characters = {"Brave", "Fierce", "Friendly", "Playful", "Majestic", "Wise", "Calm", "Talkative", "Curious", "Active"};

        for (int i = 0; i < numberOfAnimals; i++) {
            LocalDate birthDate = generateRandomDate();
            Animal animal;

            if (i < breeds.length / 2) {
                animal = new Predator(breeds[i], names[i], costs[i], characters[i], birthDate);
            } else {
                animal = new Pet(breeds[i], names[i], costs[i], characters[i], birthDate);
            }

            animals.add(animal);
        }
        return animals;
    }

    private LocalDate generateRandomDate() {
        int year = 2000 + random.nextInt(22); // Генерация года от 2000 до 2021
        int month = 1 + random.nextInt(12); // Генерация месяца
        int day = 1 + random.nextInt(28); // Генерация дня (28 день для упрощения)
        return LocalDate.of(year, month, day);
    }
}

