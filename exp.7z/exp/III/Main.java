/**
 * Главный класс для запуска программы.
 */
public class Main {
    public static void main(String[] args) {
        CreateAnimalService createAnimalService = new CreateAnimalService();
        SearchService searchService = new SearchServiceImpl();
        // Создать 10 уникальных животных
        createAnimalService.createDefaultAnimals();
        Animal[] animalsArray = createAnimalService.getAnimals(); 
        // Поиск животных, родившихся в високосный год
        String[] leapYearNames = searchService.findLeapYearNames(animalsArray);
        System.out.println("\nAnimals born in leap years:");
        for (String name : leapYearNames) {
            System.out.println(name);
        }
        // Поиск животных старше N лет
        Animal[] olderAnimals = searchService.findOlderAnimal(animalsArray, 5);
        System.out.println("\nAnimals older than 5 years:");
        for (Animal olderAnimal : olderAnimals) {
            System.out.println(olderAnimal);
        }
        // Поиск дубликатов
        System.out.println("\nFinding duplicates:");
        searchService.findDuplicate(animalsArray);
    }
}
