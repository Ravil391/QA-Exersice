import java.time.LocalDate;

/**
 * Абстрактный класс, представляющий общее животное.
 */
public abstract class AbstractAnimal implements Animal {
    protected String breed;    // порода
    protected String name;     // имя
    protected Double cost;     // цена в магазине
    protected String character; // характер
    protected LocalDate birthDate; // Дата рождения

    public AbstractAnimal(String breed, String name, Double cost, String character, LocalDate birthDate) {
        this.breed = breed;
        this.name = name;
        this.cost = cost;
        this.character = character;
        this.birthDate = birthDate;
    }

    @Override
    public String getBreed() {
        return breed;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Double getCost() {
        return cost;
    }

    @Override
    public String getCharacter() {
        return character;
    }

    @Override
    public LocalDate getBirthDate() {
        return birthDate; // Реализация нового метода
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof AbstractAnimal)) return false;
        AbstractAnimal other = (AbstractAnimal) obj;
        return breed.equals(other.breed) && name.equals(other.name) &&
               cost.equals(other.cost) && character.equals(other.character) &&
               birthDate.equals(other.birthDate);
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Breed: " + breed + ", Cost: " + cost + ", Character: " + character + ", Birth Date: " + birthDate;
    }
}
