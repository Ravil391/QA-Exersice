import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Реализация интерфейса SearchService.
 */
public class SearchServiceImpl implements SearchService {

    @Override
    public String[] findLeapYearNames(Animal[] animals) {
        if (animals == null || animals.length == 0) {
            return new String[0];
        }
        
        return Arrays.stream(animals)
                .filter(animal -> animal.getBirthDate().isLeapYear())
                .map(Animal::getName)
                .toArray(String[]::new);
    }

    @Override
    public Animal[] findOlderAnimal(Animal[] animals, int N) {
        if (animals == null || animals.length == 0 || N < 0) {
            return new Animal[0];
        }

        return Arrays.stream(animals)
                .filter(animal -> LocalDate.now().getYear() - animal.getBirthDate().getYear() > N)
                .toArray(Animal[]::new);
    }

    @Override
    public void findDuplicate(Animal[] animals) {
        if (animals == null || animals.length == 0) {
            System.out.println("No animals provided.");
            return;
        }
        
        Set<AbstractAnimal> uniqueAnimals = new HashSet<>();
        Set<AbstractAnimal> duplicates = new HashSet<>();
        
        for (Animal animal : animals) {
            if (!uniqueAnimals.add((AbstractAnimal) animal)) {
                duplicates.add((AbstractAnimal) animal);
            }
        }

        if (duplicates.isEmpty()) {
            System.out.println("No duplicates found.");
        } else {
            System.out.println("Duplicate animals:");
            for (Animal dup : duplicates) {
                System.out.println(dup);
            }
        }
    }
}

