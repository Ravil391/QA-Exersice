import java.time.LocalDate;

/**
 * Класс Pet, расширяющий AbstractAnimal.
 */
public class Pet extends AbstractAnimal {
    public Pet(String breed, String name, Double cost, String character, LocalDate birthDate) {
        super(breed, name, cost, character, birthDate);
    }

    @Override
    public String toString() {
        return "Pet - " + super.toString();
    }
}

