import java.time.LocalDate;

/**
 * Класс Predator, расширяющий AbstractAnimal.
 */
public class Predator extends AbstractAnimal {
    public Predator(String breed, String name, Double cost, String character, LocalDate birthDate) {
        super(breed, name, cost, character, birthDate);
    }

    @Override
    public String toString() {
        return "Predator - " + super.toString();
    }
}
