import java.time.LocalDate;

/**
 * Интерфейс Animal, представляющий животное.
 */
public interface Animal {
    String getBreed();
    String getName();
    Double getCost();
    String getCharacter();
    LocalDate getBirthDate(); // Новый метод для получения даты рождения
}
