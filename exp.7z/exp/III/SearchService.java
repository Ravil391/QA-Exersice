/**
 * Интерфейс SearchService с методами для поиска животных.
 */
public interface SearchService {
    String[] findLeapYearNames(Animal[] animals);
    Animal[] findOlderAnimal(Animal[] animals, int N);
    void findDuplicate(Animal[] animals);
}
