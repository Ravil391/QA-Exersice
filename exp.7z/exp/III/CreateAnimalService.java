import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Класс для создания животных.
 */
public class CreateAnimalService {
    private List<Animal> animals = new ArrayList<>();
    private Random random = new Random();

    public void createDefaultAnimals() {
        String[] breeds = {"Lion", "Tiger", "Dog", "Cat", "Falcon", "Eagle", "Goldfish", "Parrot", "Hamster", "Rabbit"};
        String[] names = {"Simba", "Shere Khan", "Buddy", "Whiskers", "Hercules", "Zephyr", "Goldie", "Polly", "Nibbles", "BunBun"};
        Double[] costs = {2500.0, 3000.0, 100.0, 150.0, 300.0, 500.0, 20.0, 100.0, 25.0, 30.0};
        String[] characters = {"Brave", "Fierce", "Friendly", "Playful", "Majestic", "Wise", "Calm", "Talkative", "Curious", "Active"};

        for (int i = 0; i < 10; i++) {
            LocalDate birthDate = generateRandomDate();
            if (i < 5) { // Первые 5 животных - хищники
                animals.add(new Predator(breeds[i], names[i], costs[i], characters[i], birthDate));
            } else { // Остальные - домашние питомцы
                animals.add(new Pet(breeds[i], names[i], costs[i], characters[i], birthDate));
            }
            System.out.println("Created: " + animals.get(animals.size() - 1));
        }
    }

    private LocalDate generateRandomDate() {
        int year = 2000 + random.nextInt(22); // Генерация года от 2000 до 2021
        int month = 1 + random.nextInt(12); // Генерация месяца
        int day = 1 + random.nextInt(28); // Генерация дня (максимум 28 для упрощения)
        return LocalDate.of(year, month, day);
    }

    public Animal[] getAnimals() {
        return animals.toArray(new Animal[0]);
    }
}


