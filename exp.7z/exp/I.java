/**
 * Класс Product представляет товар с его количеством, ценой и скидкой.
 * Содержит методы для подсчета общей стоимости товара с учетом скидки.
 */
class Product {
    // Количество товаров
    private int quantity;
    
    // Цена товара
    private double price;
    
    // Скидка на товар в процентах
    private double discount;

    /**
     * Конструктор класса Product.
     *
     * @param quantity количество товаров
     * @param price цена товара
     * @param discount скидка на товар в процентах
     */
    public Product(int quantity, double price, double discount) {
        this.quantity = quantity;
        this.price = price;
        this.discount = discount;
    }

    /**
     * Метод для расчета и вывода общей суммы покупки без скидки и со скидкой.
     */
    public void calculateTotal() {
        double totalWithoutDiscount = quantity * price; // Общая сумма без скидки
        double discountAmount = totalWithoutDiscount * (discount / 100); // Сумма скидки
        double totalWithDiscount = totalWithoutDiscount - discountAmount; // Общая сумма со скидкой
        
        // Округление до 2 знаков после запятой
        totalWithoutDiscount = Math.round(totalWithoutDiscount * 100.0) / 100.0;
        totalWithDiscount = Math.round(totalWithDiscount * 100.0) / 100.0;

        // Печать результатов
        System.out.println("Общая сумма без скидки: " + totalWithoutDiscount + " USD");
        System.out.println("Общая сумма со скидкой: " + totalWithDiscount + " USD");
    }
}


public class Main {
    public static void main(String[] args) {
        // Создание объектов Product с различными параметрами
        Product product1 = new Product(10, 15.99, 0.75);
        Product product2 = new Product(5, 20.00, 42.575);
        Product product3 = new Product(3, 50.00, 59.1);
        
        // Вызов метода для расчета сумм
        System.out.println("Продукт 1:");
        product1.calculateTotal();
        System.out.println();

        System.out.println("Продукт 2:");
        product2.calculateTotal();
        System.out.println();

        System.out.println("Продукт 3:");
        product3.calculateTotal();
    }
}
